# Vent Game Studio 1.0.0｜萬用消氣發洩遊戲系統模組

這是一套**「網頁端即開即改」＋「AI Agent 自動引導生成」**雙軌合一的萬用消氣遊戲系統模組。
無論你是想直接在手機／電腦瀏覽器上傳討厭對象的照片或短影片、自己改台詞，或是想把這套模組交給你的 **OpenAI Codex**、**Claude Code**、**Cursor**、**Antigravity** 或**本地端 LLM（Ollama / LM Studio）**，讓 AI 自動訪問你並幫你量身打造專屬的發洩遊戲，都可以透過本模組一鍵完成。

---

## 🚀 方式一：交給 AI 語言模型（Codex / Claude / 本地 LLM）自動引導製作

只要在具備檔案讀寫能力的 Agent 對話視窗貼入以下啟動指令，AI 就會自動讀取 `skills/vent-game-maker/SKILL.md`，一步步引導你提供**照片／影片**與**對方的惡劣事蹟與個性**，自動幫你寫滿五階段台詞、合成語音並生成完整遊戲：

```text
請讀取 /Users/akc/遊戲/萬用消氣遊戲系統模組_vent-game-studio/skills/vent-game-maker/SKILL.md，
使用這個萬用消氣遊戲系統模組幫我製作專屬的發洩網頁遊戲。
請依照模組內的引導流程，詢問我需要提供的照片（或短影片）、對方的稱呼、事發經過與惡劣個性，並自動幫我生成完整網站與單檔分享版！
```

### 各大 AI Agent 工具安裝位置參考

| AI 環境 | 建議放置路徑與呼叫方式 |
| :--- | :--- |
| **OpenAI Codex** | 複製 `skills/vent-game-maker/` 至專案 `.agents/skills/vent-game-maker/`，對話輸入 `$vent-game-maker` |
| **Claude Code** | 複製 `skills/vent-game-maker/` 至專案 `.claude/skills/vent-game-maker/`，對話輸入 `/vent-game-maker` |
| **本地 LLM / Cursor / Antigravity** | 直接在對話貼上 `skills/vent-game-maker/SKILL.md` 的路徑，讓 Agent 按需讀取內部的 `references/` 與 `assets/` |

---

## 🛠️ 方式二：直接在網頁打開「萬用消氣遊戲工作坊」上傳照片／改台詞

不需要寫任何程式，直接用手機或電腦打開網站（或雙擊本資料夾內的 `START-HERE.html`），點擊畫面上的 **「📸 換照片／自訂台詞」** 或右上角 **「🛠️」**：

1. **⚡ 四大預設情境一鍵切換**：內建「🚗 追撞三寶」、「💼 甩鍋慣老闆」、「🎮 擺爛雷隊友」、「💸 欠錢損友」四組完整台詞範本。
2. **📸 上傳照片或短影片（純本機處理）**：支援上傳任何 `.jpg` / `.png` / `.webp` 照片或 `.mp4` / `.mov` 短影片。
3. **🎯 臉部傷勢準心校準**：直接點擊預覽圖中對方的**鼻樑／兩眼中間**並調整大小滑桿，黑輪、OK 繃、額頭繃帶與頭頂大腫包就會自動對準他的臉！
4. **✍️ 自訂罵人與求饒台詞**：自由修改對方的稱呼、事發經過、欠扁名言、你出拳罵他的話，以及他被打倒後的痛哭懺悔詞。
5. **💾 一鍵匯出專屬單檔遊戲（`.html`）**：點擊「💾 匯出專屬單檔遊戲 (.html) 傳給朋友」，瀏覽器會直接把你上傳的照片與改好的台詞打包成一個獨立 `.html` 檔案，傳到 LINE 給朋友點開就能玩！

---

## 📦 資料夾結構說明

```text
萬用消氣遊戲系統模組_vent-game-studio/
├── README.md                              # 本說明文件（含 AI 啟動指令與使用教學）
├── START-HERE.html                        # 單檔免安裝版「萬用消氣遊戲工作坊」（雙擊即可直接玩與自訂）
├── vent-game-maker-module.zip             # 打包好的萬用 AI 系統模組壓縮包（可從網頁一鍵下載）
└── skills/
    └── vent-game-maker/                   # 核心 AI Agent 技能包
        ├── SKILL.md                       # AI Agent 主指令（引導訪談 → 五階段台詞生成 → 視覺對位 → 打包）
        ├── references/
        │   ├── interview-guide.md         # 引導使用者提供「對象、照片/影片、前因後果、個性」的提問指南
        │   ├── dialogue-writing-guide.md  # 台灣口語潤稿原則與單聲道不重疊語音規範
        │   └── ui-ux-spec.md              # 四區零遮擋手機版面與臉部準心校準規範
        ├── assets/
        │   ├── game-config-schema.json    # 標準化遊戲設定 JSON Schema
        │   ├── presets.json               # 四大預設角色台詞庫
        │   └── web-template/              # 萬用網頁遊戲與自訂工作坊前端引擎
        └── scripts/
            └── build_vent_game.js         # 自動化命令列建置與語音合成腳本
```
