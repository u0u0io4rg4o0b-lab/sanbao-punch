#!/usr/bin/env node
/**
 * build_vent_game.js — 萬用消氣發洩遊戲自動化建置腳本
 *
 * 用法：
 *   node build_vent_game.js --config path/to/config.json --output path/to/output-dir
 *
 * 功能：
 *   1. 讀取使用者或 AI Agent 產出的遊戲設定 JSON（含圖片/影片路徑、臉部座標與五階段台詞）
 *   2. 自動將網頁遊戲引擎範本（assets/web-template/）複製至輸出目錄並注入 config.js
 *   3. 若在 macOS 環境且具備 /usr/bin/say 與 ffmpeg，自動為所有台詞合成單聲道 .mp3 語音檔
 *   4. 自動打包產出一鍵可分享的單檔版 HTML（<gameTitle>_單檔版.html）
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const args = process.argv.slice(2);
function getArg(flag, def) {
  const idx = args.indexOf(flag);
  return idx !== -1 && args[idx + 1] ? args[idx + 1] : def;
}

const skillRoot = path.resolve(__dirname, '..');
const templateDir = path.join(skillRoot, 'assets', 'web-template');
const configPath = getArg('--config', null);
const outDir = path.resolve(getArg('--output', path.join(process.cwd(), 'dist-vent-game')));
const skipTts = args.includes('--skip-tts');

fs.mkdirSync(outDir, { recursive: true });

// 1. Copy web-template files
for (const file of ['index.html', 'style.css', 'config.js', 'engine.js', 'default-target.jpg']) {
  const src = path.join(templateDir, file);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, path.join(outDir, file));
  }
}

// 2. If custom config JSON provided, merge and write config.js
let cfg = null;
if (configPath && fs.existsSync(configPath)) {
  cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  if (cfg.mediaSrc && !/^data:|^https?:/i.test(cfg.mediaSrc)) {
    const absMedia = path.resolve(path.dirname(configPath), cfg.mediaSrc);
    if (fs.existsSync(absMedia)) {
      const ext = path.extname(absMedia).toLowerCase();
      const dstName = 'custom-target' + ext;
      fs.copyFileSync(absMedia, path.join(outDir, dstName));
      cfg.mediaSrc = dstName;
    }
  }
  const presetsPath = path.join(skillRoot, 'assets', 'presets.json');
  const presets = fs.existsSync(presetsPath) ? JSON.parse(fs.readFileSync(presetsPath, 'utf8')) : {};
  const configJsContent = `window.VENT_PRESETS = ${JSON.stringify(presets, null, 2)};\nwindow.VENT_INITIAL_CONFIG = ${JSON.stringify(cfg, null, 2)};\n`;
  fs.writeFileSync(path.join(outDir, 'config.js'), configJsContent, 'utf8');
} else {
  // Load default config from template config.js
  global.window = {};
  require(path.join(outDir, 'config.js'));
  cfg = global.window.VENT_INITIAL_CONFIG;
}

// 3. Optional macOS TTS MP3 synthesis
const hasSay = fs.existsSync('/usr/bin/say');
const ffmpegPaths = ['/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/usr/bin/ffmpeg'];
const ffmpegBin = ffmpegPaths.find((p) => fs.existsSync(p));

if (!skipTts && hasSay && ffmpegBin && cfg) {
  const audioDir = path.join(outDir, 'audio');
  fs.mkdirSync(audioDir, { recursive: true });
  const jobs = [
    ...(cfg.story || []).map((x) => ({ ...x, voice: 'Grandpa (中文（台灣）)', rate: '185' })),
    ...(cfg.shouts || []).map((x) => ({ ...x, voice: 'Rocko (中文（台灣）)', rate: '195' })),
    ...((cfg.stages || []).flat()).map((x) => ({ ...x, voice: 'Grandpa (中文（台灣）)', rate: '182' })),
    ...(cfg.confess || []).map((x) => ({ ...x, voice: 'Grandpa (中文（台灣）)', rate: '168' })),
  ];
  for (const j of jobs) {
    const aiff = path.join('/tmp', `vent_${j.id}.aiff`);
    const mp3 = path.join(audioDir, `${j.id}.mp3`);
    try {
      execFileSync('/usr/bin/say', ['-v', j.voice, '-r', j.rate, '-o', aiff, j.say || j.text]);
      execFileSync(ffmpegBin, [
        '-y', '-loglevel', 'error', '-i', aiff,
        '-af', 'highpass=f=90,acompressor=threshold=-16dB:ratio=2.5:attack=10:release=120,volume=1.35',
        '-codec:a', 'libmp3lame', '-b:a', '48k', '-ac', '1', '-ar', '24000', mp3,
      ]);
      fs.unlinkSync(aiff);
    } catch (e) {}
  }
  console.log(`Synthesized ${jobs.length} MP3 voice files in ${audioDir}`);
}

// 4. Build single-file portable HTML
const html = fs.readFileSync(path.join(outDir, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(outDir, 'style.css'), 'utf8');
const configJs = fs.readFileSync(path.join(outDir, 'config.js'), 'utf8');
const engineJs = fs.readFileSync(path.join(outDir, 'engine.js'), 'utf8');

let imgB64 = '';
const defaultImgPath = path.join(outDir, 'default-target.jpg');
if (fs.existsSync(defaultImgPath)) {
  imgB64 = 'data:image/jpeg;base64,' + fs.readFileSync(defaultImgPath).toString('base64');
}

const bundled = html
  .replace('<link rel="stylesheet" href="style.css">', `<style>\n${css}\n</style>`)
  .replace(/default-target\.jpg/g, imgB64 || 'default-target.jpg')
  .replace('<script src="config.js"></script>', `<script>\n${configJs}\n</script>`)
  .replace('<script src="engine.js"></script>', `<script>\n${engineJs}\n</script>`);

const singleName = `${(cfg && cfg.gameTitle) || '萬用消氣拳'}_單檔版.html`;
const singlePath = path.join(outDir, singleName);
fs.writeFileSync(singlePath, bundled, 'utf8');
console.log(`Built Universal Vent Game in: ${outDir}`);
console.log(`Single-file bundle: ${singlePath}`);
